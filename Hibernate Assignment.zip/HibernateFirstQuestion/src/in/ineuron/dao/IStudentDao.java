package in.ineuron.dao;

import in.ineuron.dto.Student;

public interface IStudentDao {
	
	// operation to be implemented

	public Student findById(Integer sid);

	

}
