package in.ineuron.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import in.ineuron.dto.Student;
import in.ineuron.util.HibernateUtil;

//Persistence logic using JDBC API
public class StudentDaoImpl implements IStudentDao {

	Session session = HibernateUtil.getSession();


	@Override
	public String updateStudent(Student student) {
		return "failure";
	}

	
	@Override
	public Student findById(Integer sid) {
		Student student = session.get(Student.class, sid);
		if (student != null)
			return student;
		else
			return null;
	}

}
