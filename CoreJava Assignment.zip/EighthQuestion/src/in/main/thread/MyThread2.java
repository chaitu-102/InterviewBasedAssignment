package in.main.thread;

public class MyThread2 extends Thread{
	public void run() {
		System.out.println("Odd Numbers");
		System.out.println("===========");
		for(int i=1;i<=10;i++) {
			if(i%2==1) {
				System.out.println(i);
			}
		}
	}
}
