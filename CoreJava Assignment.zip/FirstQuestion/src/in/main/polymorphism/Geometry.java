package in.main.polymorphism;

public class Geometry {
	public void display(Shapes s) {
		s.input();
		s.compute();
		s.display();
	}
}
