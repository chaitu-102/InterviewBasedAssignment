package in.main.polymorphism;

import java.util.Scanner;

public class Rectangle implements Shapes {
	float length;
	float breadth;
	float area;
	float perimeter;
	Scanner s=null;
	@Override
	public void input() {
		s=new Scanner(System.in);
		System.out.print("Enter the length of the Rectangle::");
		length=s.nextFloat();
		System.out.print("Enter the Breadth of the Rectangle::");
		breadth=s.nextFloat();
	}

	@Override
	public void compute() {
		area=length*breadth;
		perimeter=2*(length*breadth);
		
	}

	public void display() {
		System.out.println("Area of the Rectangle is::"+area);
		System.out.println("Perimeter of the Rectangle is::"+perimeter);
		
	}
	
	
}
