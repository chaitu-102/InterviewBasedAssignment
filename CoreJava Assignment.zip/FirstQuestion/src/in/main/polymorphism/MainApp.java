package in.main.polymorphism;

public class MainApp {

	public static void main(String[] args) {
		Geometry s=new Geometry();
		Shapes s1=new Rectangle();
		Shapes s2=new Square();
		Shapes s3=new Circle();
		s.display(s1);
		s.display(s2);
		s.display(s3);
	}

}
