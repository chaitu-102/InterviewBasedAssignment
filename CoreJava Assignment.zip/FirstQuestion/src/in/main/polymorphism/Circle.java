package in.main.polymorphism;

import java.util.Scanner;

public class Circle implements Shapes{
	float radius;
	double area;
	double perimeter;
	Scanner s=null;
	@Override
	public void input() {
		s=new Scanner(System.in);
		System.out.print("Enter the radius of the Circle::");
		radius=s.nextFloat();
	}

	@Override
	public void compute() {
		area=Math.PI*(radius*radius);
		perimeter=2*(Math.PI*radius);
		
	}

	public void display() {
		System.out.println("Area of the Circle is::"+area);
		System.out.println("Perimeter of the Circle is::"+perimeter);
		
	}
}
