package in.main.polymorphism;

public interface Shapes {
	public void input();
	public void compute();
	public void display();
}
