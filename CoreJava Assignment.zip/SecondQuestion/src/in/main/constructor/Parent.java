package in.main.constructor;

public class Parent {
	public Parent() {
		System.out.println("Parent Class Constructor...");
	}
}
