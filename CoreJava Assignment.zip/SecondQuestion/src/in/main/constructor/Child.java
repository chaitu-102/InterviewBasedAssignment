package in.main.constructor;

public class Child extends Parent {
	public Child(){
		super();
		System.out.println("Child Class Constructor...");
	}
}
