package in.main.exception;

public class MainApp {

	public static void main(String[] args) {
		NegativeException ne=new NegativeException();
		ne.display();

	}

}
