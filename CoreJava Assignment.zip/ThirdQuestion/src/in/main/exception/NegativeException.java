package in.main.exception;

import java.util.Scanner;

class NegativeNumberException extends Exception{
	String value;
	public NegativeNumberException(String s){
		value=s;
	}
}
public class NegativeException {
	public void display() {
		int input=0;
		Scanner s=new Scanner(System.in);
		try {
			System.out.print("Enter the number::");
			input=s.nextInt();
			if(input>0) {
				System.out.println("Entered Number is::"+input);
			}
			if(input<0) {
				System.out.println("Negative Number");
				throw new NegativeNumberException("Negative Number");
			}
		}
		catch(NegativeNumberException ne) {
			System.out.println(ne);
		}
	}

	}

