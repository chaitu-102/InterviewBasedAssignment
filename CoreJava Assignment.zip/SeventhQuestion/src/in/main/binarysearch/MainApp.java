package in.main.binarysearch;

public class MainApp {

	public static void main(String[] args) {
		BinarySearch bs=new BinarySearch();
		bs.search();
	}

}
