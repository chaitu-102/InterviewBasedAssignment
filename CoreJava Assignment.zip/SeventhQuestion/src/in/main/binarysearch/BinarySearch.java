package in.main.binarysearch;

import java.util.Scanner;

public class BinarySearch {
	public void search() {
	int size;
	Scanner scan=new Scanner(System.in);
	System.out.print("Enter the size of the Array::");
	size=scan.nextInt();
	int[]arr=new int[size];
	for(int i=0;i<size;i++) {
		System.out.print("Enter the element to add in the index"+" "+i+"::");
		int data=scan.nextInt();
		arr[i]=data;
	}
	for(int i=0;i<arr.length;i++) {
		for(int j=i+1;j<arr.length;j++) {
			if(arr[i]>arr[j]) {
				int temp=arr[j];
				arr[j]=arr[i];
				arr[i]=temp;
			}
			
		}
	}
	int low=0;
	int high=arr.length-1;
	
	System.out.print("Enter the key to search::");
	int key=scan.nextInt();
	while(low<=high) {
		int middle=(low+high)/2;
		if(key==arr[middle]) {
			System.out.println("Key found at index:"+middle);
			break;
		}
		else if(key<arr[middle]) {
			high=middle-1;
		}
		else if(key>arr[middle]) {
			low=middle+1;
		}
	}
	if(low>high) {
		System.out.println("Key not found");
	}
}
}
