package in.main.atm;

import java.util.Scanner;
class Atm{
	Scanner s=new Scanner(System.in);
	int acc=1234;
	int pin=7890;
	int cacc;
	int cpin;
	int option;
	int amount=0;
	public void input() {
		System.out.println("Welcome TO Atm Machine");
		System.out.println("=========================");
		System.out.println("Please Enter the Account No:");
		cacc=s.nextInt();
		System.out.println("Please Enter the Pin:");
		cpin=s.nextInt();
	}
	void disp() {
		if(acc==cacc && pin==cpin) {
			System.out.println("1:Check Balance");
			System.out.println("2:Withdraw");
			System.out.println("3:Depoist");
			System.out.println("4:Exit");
			System.out.println("5:Back to main_menu");
			System.out.println("Please Enter the option for Operation(1-5)");
			option=s.nextInt();
	}
		else {
			System.out.println("Please Enter Correct accNo&Pin");
			input();
		}
	}
	void operate() {
		if(option==1) {
			System.out.println("Current Balance is:"+amount);
			disp();
			operate();
		}
		
		if(option==2) {
			System.out.println("Enter the amount you want to withdraw:");
			int withdraw=s.nextInt();
			int withdrawamount=withdraw;
			if(amount==0){
				System.out.println("Your Account has:"+amount);
				System.out.println("Please depoist money to withdraw");
				disp();
				operate();
			}
			else if(amount<withdrawamount) {
				System.out.println("InSufficient Funds");
				System.out.println("Current Balance is::"+amount);
				disp();
				operate();
			}
			else {
				
				System.out.println("Amount withdrawn Successfully of Rs:"+withdraw);
				amount=amount-withdraw;
				disp();
				operate();
			}
			
			
		}
		if(option==3) {
			System.out.println("Enter the amount you want to depoist:");
				int depoist;
				depoist=s.nextInt();
				System.out.println("Amount depoisted Successfully of Rs:"+depoist);
				amount=amount+depoist;
				disp();
				operate();
			}
		
		if(option==4) {
			System.out.println("Terminated Successfully...");
			System.exit(0);
		}
		
		}
		
	
}
	

