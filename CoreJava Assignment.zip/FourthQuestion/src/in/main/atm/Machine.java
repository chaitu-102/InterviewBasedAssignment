package in.main.atm;

public class Machine {
	Atm a=new Atm();
	void execute() {
		a.input();
		a.disp();
		a.operate();
	}
}
