package in.main.atm;

public class MainApp {
	public static void main(String[]args) {
		Machine m=new Machine();
		m.execute();
	}
}
