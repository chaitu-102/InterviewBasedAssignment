package in.main.producerconsumer;

class Producer extends Thread {
	
	static double total=0;
	public void run() {
		synchronized(this) {
			System.out.println("Producer Thread Started Execution");
			for(int i=1;i<=5;i++) {
				total=total+Math.random();
			}
			System.out.println(total);
			this.notify();
		}
	}
}
	public class Producer_Consumer{
	public static void main(String[] args) {
		Producer pc=new Producer();
		synchronized(pc) {
			System.out.println("In Waiting State");
			try {
				pc.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Total="+pc.total);
	}
	}
}
