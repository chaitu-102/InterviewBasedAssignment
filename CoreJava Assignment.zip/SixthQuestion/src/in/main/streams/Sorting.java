package in.main.streams;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Sorting {
	public void sort() {
		int size;
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the Size of the ArrayList::");
		size=s.nextInt();
		ArrayList<Integer> al=new ArrayList<Integer>(size);
		for(int i=0;i<size;i++) {
			System.out.print("Enter the Values in the ArrayList::");
			Integer values=s.nextInt();
			al.add(values);
		}
		
		ArrayList<Integer>streamList=(ArrayList<Integer>) al.stream().sorted().collect(Collectors.toList());
		System.out.println(streamList);
	}
}
