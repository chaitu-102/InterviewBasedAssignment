package in.main.streams;

public class MainApp {

	public static void main(String[] args) {
		Filtering f=new Filtering();
		Sorting s=new Sorting();
		f.filter();
		s.sort();
	}

}
