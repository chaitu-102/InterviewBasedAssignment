package in.main.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class List {
	public void searching() {
		int size;
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the size of the ArrayList::");
		size=s.nextInt();
		ArrayList list=new ArrayList(size);
		for(int i=0;i<size;i++) {
			System.out.println("Enter the Elements to insert in the index"+" "+i+"::");
			Integer element=s.nextInt();
			list.add(element);
		}
		Collections.sort(list);
		Integer secondsmall=(Integer) list.get(0+1);
		Integer secondlarge=(Integer) list.get(list.size()-2);
		System.out.println("Second Smallest Element in the ArrayList is::"+secondsmall);
		System.out.println("Second Largest Element in the ArrayList is::"+secondlarge);
		}
	}

