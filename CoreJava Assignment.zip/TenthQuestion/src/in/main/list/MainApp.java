package in.main.list;

public class MainApp {

	public static void main(String[] args) {
		List l=new List();
		l.searching();

	}

}
