package in.jdbc.main;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class JdbcUtil {
	private JdbcUtil() {
		
	}
	static {
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException ce) {
			ce.printStackTrace();
		}
	}
	public static Connection getJdbcConnection()throws IOException,SQLException {
		FileInputStream fis=new FileInputStream("F:\\JavaApps\\JDBCProject\\src\\in\\app\\properties\\application.properties");
		Properties p=new Properties();
		p.load(fis);
		Connection con=DriverManager.getConnection(p.getProperty("url"),p.getProperty("user"),p.getProperty("password"));
		return con;
	}
	public static void option() {
		System.out.println("1.Press 1 for Insert Operation");
		System.out.println("2.Press 2 for Select Operation");
		System.out.println("3.Press 3 for Update Operation");
		System.out.println("4.Press 4 for Delete Operation");
		System.out.println("5.Press 5 for Exit");
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the Option(1-5) for operation:");
		int option=s.nextInt();

		if(option==1) {
			InsertApp.insertOperation();
		}

		if(option==2) {
			SelectApp.selectOperation();
		}

		if(option==3) {
			UpdateApp.updateOperation();
		}

		if(option==4) {
			DeleteApp.deleteOperation();
			
		}

		if(option==5) {
			System.out.println("Application is Closed...");
			System.exit(0);
		}
		if(option>5 || option<1) {
			System.out.println("Please Enter the Correct Option");
			option();
		}
	}
	public static void cleanUp(Connection c,Statement s,ResultSet rs)throws SQLException {
		if(c!=null) {
			c.close();
		}
		if(s!=null) {
			s.close();
		}
		if(rs!=null) {
			rs.close();
		}
	}
}
