package in.jdbc.main;

public class Operations {

	public static void main(String[] args) {
			JdbcUtil.option();
		}
}
