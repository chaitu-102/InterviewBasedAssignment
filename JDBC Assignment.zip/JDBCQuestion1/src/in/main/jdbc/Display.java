package in.main.jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Display {

	public static void main(String[] args) {
		Connection c=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		 try {
			c=JdbcUtil.getJdbcConnection();
			String query="select pid,pname,age,team from players";
			if(c!=null) {
				pstmt=c.prepareStatement(query);
			}
			if(pstmt!=null) {
				rs=pstmt.executeQuery();
				System.out.println("Id\tName\tAge\tTeam");
			}
			if(rs!=null) {
				while(rs.next()) {
					System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getInt(3)+"\t"+rs.getString(4));
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
	
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
