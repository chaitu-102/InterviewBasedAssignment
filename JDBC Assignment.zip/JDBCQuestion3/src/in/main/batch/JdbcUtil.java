package in.main.batch;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtil {
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException ce) {
			ce.printStackTrace();
		}
	}
	public static Connection getJdbcConnection() throws SQLException, IOException {
		FileInputStream fis=new FileInputStream("F:\\JavaApps\\JDBCAssignment\\JDBCQuestion3\\src\\in\\main\\properties\\application.properties");
		Properties p=new Properties();
		p.load(fis);
		Connection con=DriverManager.getConnection(p.getProperty("url"),p.getProperty("user"),p.getProperty("password"));
		return con;
	}
}
