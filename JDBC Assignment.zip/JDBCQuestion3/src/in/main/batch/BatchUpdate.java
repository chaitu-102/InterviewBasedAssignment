package in.main.batch;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.util.*;;

public class BatchUpdate {

	public static void main(String[] args) {
		Connection con=null;
		PreparedStatement pstmt=null;
		try {
			con=JdbcUtil.getJdbcConnection();
			String query="insert into players(pname,age,team)values(?,?,?)";
			if(con!=null) {
				pstmt=con.prepareStatement(query);
				FileReader fr=new FileReader("F:\\JavaApps\\JDBCAssignment\\JDBCQuestion3\\src\\in\\main\\reader\\input.text");
				BufferedReader br=new BufferedReader(fr);
				while(true) {
				Scanner s=new Scanner(System.in);
				String name=br.readLine();
				pstmt.setString(1,name);
				String age=br.readLine();
				pstmt.setInt(2, Integer.parseInt(age));
				String team=br.readLine();
				pstmt.setString(3,team);
				pstmt.addBatch();
			
			System.out.print("Do you want to insert another recoed{Yes/NO]::");
			String input=s.nextLine();
			if(input.equalsIgnoreCase("yes")) {
				continue;
			}
			else {
				break;
			}
			}
		}
			pstmt.executeBatch();
			System.out.println("Data Inserted Successfully...");
		}
		catch(SQLException se) {
			se.printStackTrace();
		}
		catch(IOException ie) {
			ie.printStackTrace();
		}
	}

}
