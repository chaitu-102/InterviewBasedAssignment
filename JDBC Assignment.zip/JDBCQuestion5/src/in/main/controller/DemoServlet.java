package in.main.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.main.dto.Players;
import in.main.factory.ServiceFactory;
import in.main.service.IService;

@WebServlet("/demo")
public class DemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   @Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
	IService service=ServiceFactory.serviceFactory();
	Players p=new Players();
	 p=service.display(p);
	int id=p.getId();
	String name=p.getName();
	int age=p.getAge();
	String team=p.getTeam();
	pw.println("<html>");
	pw.println("<head>");
	pw.println("<title>OUTPUT</title>");
	pw.println("<body>");
	pw.println("<center>");
	pw.println("<table border='1'>");
	pw.println("<tr>");
	pw.println("<th>ID</th><th>Name</th><th>Age</th><th>Team</th>");
	pw.println("</tr>");
	pw.println("<tr>");
	pw.println("<td>"+id+"</td><td>"+name+"</td><td>"+age+"</td><td>"+team+"</td>");
	pw.println("</tr>");
	pw.println("</table>");
	pw.println("</center>");
	pw.println("</body>");
	pw.println("</html>");
   }
}
