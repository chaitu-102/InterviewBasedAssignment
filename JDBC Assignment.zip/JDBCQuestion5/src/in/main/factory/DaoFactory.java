package in.main.factory;

import in.main.dao.DaoImpl;
import in.main.dao.IDao;

public class DaoFactory {
	private DaoFactory() {
		
	}
	static IDao dao=null;
	public static IDao daoFactory() {
		dao=new DaoImpl();
		return dao;
		
	}
}
