package in.main.factory;

import in.main.service.IService;
import in.main.service.ServiceImpl;

public class ServiceFactory {
	private ServiceFactory() {
		
	}
	static IService service=null;
	public static IService serviceFactory() {
		service=new ServiceImpl();
		return service;
		
	}
}
