package in.main.service;

import in.main.dao.IDao;
import in.main.dto.Players;
import in.main.factory.DaoFactory;

public class ServiceImpl implements IService{

	@Override
	public Players display(Players p) {
		IDao dao=DaoFactory.daoFactory();
		return dao.display(p);	
	}

}
