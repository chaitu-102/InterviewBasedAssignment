package in.main.service;

import in.main.dto.Players;

public interface IService {
	public Players display(Players p);
}
