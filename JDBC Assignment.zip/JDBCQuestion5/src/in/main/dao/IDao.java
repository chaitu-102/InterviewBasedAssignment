package in.main.dao;

import in.main.dto.Players;

public interface IDao {
	public Players display(Players p); 
}
