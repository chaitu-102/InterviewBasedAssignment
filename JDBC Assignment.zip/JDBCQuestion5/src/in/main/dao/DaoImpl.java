package in.main.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import in.main.dto.Players;
import in.main.util.JdbcUtil;

public class DaoImpl implements IDao{
	public Players display(Players p) {
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			con=JdbcUtil.jdbcConnection();
			String query="select pid,pname,age,team from players";
			if(con!=null) {
				pstmt=con.prepareStatement(query);
			}
			if(pstmt!=null) {
				rs=pstmt.executeQuery();
			}
			if(rs!=null) {
			
					while(rs.next()) {
					p.setId(rs.getInt(1));
					p.setName(rs.getString(2));
					p.setAge(rs.getInt(3));
					p.setTeam(rs.getString(4));
				}
			}
		
		}
		catch(IOException ie) {
			ie.printStackTrace();
		}
		catch(SQLException  se) {
			se.printStackTrace();
		}
		return p;
		
		
		
	
}
}
