package in.main.jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteApp {
	public static void deleteOperation()
	{
		Connection c=null;
		PreparedStatement pstmt=null;
		try {
			c=JdbcUtil.getJdbcConnection();
			String query="delete from players where pid=?";
			if(c!=null) {
				pstmt=c.prepareStatement(query);
			}
			if(pstmt!=null) {
				Scanner s=new Scanner(System.in);
				System.out.println("Enter the Id:");
				int id=s.nextInt();
				pstmt.setInt(1, id);
				int deletedRow=pstmt.executeUpdate();
				if(deletedRow==1) {
					System.out.println("Deleted Successfully...");
				}
				if(deletedRow==0) {
					System.out.println("Deletion is Failed...");
				}
			}
		}
		catch(SQLException se) {
			se.printStackTrace();
		}
		catch(IOException ie) {
			ie.printStackTrace();
		}
	}
}
