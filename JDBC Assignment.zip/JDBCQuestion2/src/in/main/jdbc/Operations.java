package in.main.jdbc;

public class Operations {

	public static void main(String[] args) {
			JdbcUtil.option();
		}
}
