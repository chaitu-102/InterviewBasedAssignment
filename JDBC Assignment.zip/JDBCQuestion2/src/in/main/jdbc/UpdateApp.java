package in.main.jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateApp {
	public static void updateOperation() {
		Connection c=null;
		PreparedStatement pstmt=null;
		try {
			c=JdbcUtil.getJdbcConnection();
			String query="update players set pname=?,age=?,team=? where pid=?";
			if(c!=null) {
				pstmt=c.prepareStatement(query);
			}
			if(pstmt!=null) {
				Scanner s=new Scanner(System.in);
				System.out.print("Enter the Name to Update:");
				String name=s.next();
				System.out.print("Enter the Age to Update:");
				int age=s.nextInt();
				System.out.print("Enter the Team to Update:");
				String team=s.next();
				System.out.print("Enter the Id to Update the Details:");
				int id=s.nextInt();
				pstmt.setNString(1,name);
				pstmt.setInt(2,age);
				pstmt.setString(3, team);
				pstmt.setInt(4, id);
				int update=pstmt.executeUpdate();
				if(update==1) {
					System.out.println("Data Updated Successfully...");
				}
				if(update==0) {
					System.out.println("Data Updation is Failed...");
				}
			}
		}
		catch(IOException ie) {
			ie.printStackTrace();
		}
		catch(SQLException se) {
			se.printStackTrace();
		}
		finally {
			try {
			JdbcUtil.cleanUp(c, pstmt, null);
			}
			catch(SQLException se) {
				se.printStackTrace();
			}
		}
	}
}
