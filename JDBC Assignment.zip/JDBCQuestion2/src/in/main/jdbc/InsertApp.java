package in.main.jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertApp {
	public static void insertOperation() {
		Connection c=null;
		PreparedStatement pstmt=null;
		try {
			
			c=JdbcUtil.getJdbcConnection();
			String query="insert into players(pname,age,team)values(?,?,?)";
			if(c!=null) {
				pstmt=c.prepareStatement(query);
			}
			if(pstmt!=null) {
				Scanner s=new Scanner(System.in);
				System.out.print("Enter the Name to Insert:");
				String name=s.next();
				System.out.print("Enter the Age to Insert:");
				int age=s.nextInt();
				System.out.print("Enter the TeamName to Insert:");
				String team=s.next();
				pstmt.setString(1,name);
				pstmt.setInt(2, age);
				pstmt.setString(3, team);
				int rowsAffected=pstmt.executeUpdate();
				if(rowsAffected==1) {
				System.out.println("Record Inserted Successfully...");
				}
				if(rowsAffected==0) {
					System.out.println("Record Insertion Failed...");
				}
			}
		}
		
		catch(IOException ie) {
			ie.printStackTrace();
		}
		catch(SQLException se) {
			se.printStackTrace();
		}
		finally {
			try {
			JdbcUtil.cleanUp(c, pstmt, null);
			}
			catch(SQLException se) {
				se.printStackTrace();
			}
		}
	}
}
